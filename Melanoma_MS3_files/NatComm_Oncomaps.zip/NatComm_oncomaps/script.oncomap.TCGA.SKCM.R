#!/usr/bin/env R

if (!require(OncomapAmpDel)) {
    install.packages('OncomapAmpDel_0.1.0.tar.gz', type='source', repo=NULL)
    require(OncomapAmpDel)
}

##

main.tag = 'TCGA high-purity metastatic'

col.typ=c(MEL='deeppink4', NPLAS='wheat4', MES='royalblue4')

## filenames

input.subtype.fn='TCGA.s77.cluster3.tsv'
input.mut.fn='TCGA.mutation.selected.tsv'
input.cn.fn='TCGA.copynumber.selected.tsv'
input.mut_counts.fn='TCGA.SKCM.Mut.counts.tsv'
input.mut.AC_type.fn='TCGA.SKCM.Mut.ACtypes.tsv'

##

setting.mut_cn.color.fn=NULL
#setting.mut_cn.color.fn='Mut_CN.colors.tsv'

#setting.mut_cn.goi.fn=NULL
setting.mut_cn.goi.fn='Mut_CN.goi.SW.tsv'

pdf.h=14
pdf.w=16
pdf.mar=c(6,5,3,8)

cex.names=0.7
cex.genes=0.5

## Copy Number setting

cn.col=c(amp='brown', del='darkgreen', wt='gray')

amp.cut = 0.5
del.cut = -0.5

min.number.mut.cna = 3

## Mutation barplots settings

mut.synom.cols = c(NonSyn='blue', Synom='pink')
mut.AC_type.cols = c("C>T"="red", "C>A"="pink", "A>(C/G)"="orange", "others"="cyan" )

# plot.snms=NULL
plot.snms=readLines('TCGA.s77.plot.snms.txt')

plot.snms

##

output.pdf.fn='example.TCGA.oncomap.v2.pdf'

plot_Oncomap_AmpDel(
    main = main.tag,
    input.subtype.fn = input.subtype.fn,
    input.mut.fn = input.mut.fn,
    input.cn.fn = input.cn.fn,
    input.mut_counts.fn = input.mut_counts.fn,
    input.mut.AC_type.fn = input.mut.AC_type.fn,
    output.pdf.fn = output.pdf.fn,
    plot.snms = plot.snms,
    setting.mut_cn.goi.fn=setting.mut_cn.goi.fn,
    setting.mut_cn.color.fn = setting.mut_cn.color.fn,
    col.typ=col.typ,
    pdf.h=pdf.h,
    pdf.w=pdf.w,
    pdf.mar=pdf.mar,
    mut.synom.cols=mut.synom.cols,
    mut.AC_type.cols=mut.AC_type.cols,
    cex.names=cex.names,
    cex.genes=cex.genes,
    frameshift.as.nonsyn.mut=F
)


##

input.scores.fn='TCGA.hp77.MelMes.scores.tsv'
melmes = read.data9(input.scores.fn)
melmes[1:4,,drop=F]

output.pdf.fn2='example.TCGA.oncomap.scores.v2.pdf'

plot_Oncomap_AmpDel(
    main = main.tag,
    input.subtype.fn = melmes,
    input.mut.fn = input.mut.fn,
    input.cn.fn = input.cn.fn,
    input.mut_counts.fn = input.mut_counts.fn,
    input.mut.AC_type.fn = input.mut.AC_type.fn,
    output.pdf.fn = output.pdf.fn2,
    plot.snms = plot.snms,
    setting.mut_cn.goi.fn=setting.mut_cn.goi.fn,
    setting.mut_cn.color.fn = setting.mut_cn.color.fn,
    col.typ=col.typ,
    pdf.h=pdf.h,
    pdf.w=pdf.w,
    pdf.mar=pdf.mar,
    mut.synom.cols=mut.synom.cols,
    mut.AC_type.cols=mut.AC_type.cols,
    cex.names=cex.names,
    cex.genes=cex.genes,
    frameshift.as.nonsyn.mut=F
)

