#!/usr/bin/env R

if (!require(OncomapAmpDel)) {
    install.packages('OncomapAmpDel_0.1.0.tar.gz', type='source', repo=NULL)
    require(OncomapAmpDel)
}

##

main.tag = 'Melanoma celllines'

## filenames

#input.subtype.fn='MS3.class.labels.s53.tsv'
#col.typ=c(MEL='deeppink4', NPLAS='wheat4', MES='royalblue4')

input.subtype.fn='MS53.platforms.subtypes.k3.tsv'
col.typ=c('red', 'darkgreen', 'blue')

input.mut.fn='MS3.s71.Mutect2.Gene_Sample.tsv'
input.cn.fn='MS3.s71.CN.bygene.mat.tsv'

input.mut_counts.fn='MS3.s71.Mut.counts.tsv'
input.mut.AC_type.fn='MS3.s71.Mut.ACtypes.tsv'

##

setting.mut_cn.color.fn=NULL
#setting.mut_cn.color.fn='Mut_CN.colors.tsv'

#setting.mut_cn.goi.fn=NULL
setting.mut_cn.goi.fn='Mut_CN.goi.SW.tsv'

pdf.h=14
pdf.w=16
pdf.mar=c(6,5,3,8)

cex.names=0.7
cex.genes=0.5

## Copy Number setting

cn.col=c(amp='brown', del='darkgreen', wt='gray')

amp.cut = 0.5
del.cut = -0.5

min.number.mut.cna = 3

## Mutation barplots settings

mut.synom.cols = c(NonSyn='blue', Synom='pink')
mut.AC_type.cols = c("C->T"="red", "C->A"="pink", "A->(C/G)"="orange", "flip"="cyan", "null+indel"="yellow" )

#plot.snms=NULL
plot.snms=readLines('MS3.plot.snms.txt')

plot.snms

##

output.pdf.fn='example.MS3.oncomap.v2.pdf'

plot_Oncomap_AmpDel(
    main = main.tag,
    input.subtype.fn = input.subtype.fn,
    input.mut.fn = input.mut.fn,
    input.cn.fn = input.cn.fn,
    input.mut_counts.fn = input.mut_counts.fn,
    input.mut.AC_type.fn = input.mut.AC_type.fn,
    output.pdf.fn = output.pdf.fn,
    plot.snms = plot.snms,
    setting.mut_cn.goi.fn=setting.mut_cn.goi.fn,
    setting.mut_cn.color.fn = setting.mut_cn.color.fn,
    col.typ=col.typ,
    pdf.h=pdf.h,
    pdf.w=pdf.w,
    pdf.mar=pdf.mar,
    mut.synom.cols=mut.synom.cols,
    mut.AC_type.cols=mut.AC_type.cols,
    cex.names=cex.names,
    cex.genes=cex.genes,
    frameshift.as.nonsyn.mut=T
)

