#!/usr/bin/env R

if (!require(CompGenoCN)) {
    install.packages('CompGenoCN_0.0.4.tar.gz', type='source', repo=NULL)
    require(CompGenoCN)
}

snms.mat=read.table('MS3.class.labels.s53.tsv', sep='\t', header=T, as.is=T)
snms.cls=factor(snms.mat[,'Subtype'], levels=c('MEL', 'NPLAS', 'MES'))
names(snms.cls) = snms.mat[,'Sample']
table(snms.cls)

seg=read.table('MS3.Gistic2.s71.hg19.seg.tsv', sep='\t', header=T, as.is=T)
seg[1:4, ]
dim(seg)

work.tag='MS3_CN_seg'
title='Melanoma cell lines'

cls.cols=c(MEL='brown', NPLAS='orange', MES='darkgreen')
compare.classes=c('MEL', 'MES')

nPerm=500
genome='hg19'

pdf.fn='Fig3C.celllines.segmap.map.pdf'

{
    print('SegMap Start')
    
    plot_CN_seg_all(seg, snms.cls, 
                    work.tag=work.tag, 
                    main=title, 
                    compare.classes=compare.classes, 
                    cls.cols=cls.cols, 
                    nPerm=nPerm, 
                    pdf.fn=pdf.fn, fh=12, fw=16, 
                    minseg=1, genome=genome
                   )

    print('SegMap Done')
}

